# Overview

In this folder you can put some files that help participants get started with making submissions for your task! This could be some code for the baselines and any other instructions that might be helpful.
